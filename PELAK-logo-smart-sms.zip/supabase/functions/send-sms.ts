// Supabase Auth Send SMS Hook -> Kavenegar Verify/Lookup.
// Deploy with JWT verification disabled; authenticate with Standard Webhooks signature.
import { Webhook } from 'npm:standardwebhooks@1.0.0';

Deno.serve(async (req) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });
  const secret = Deno.env.get('SEND_SMS_HOOK_SECRET');
  const apiKey = Deno.env.get('KAVENEGAR_API_KEY');
  if (!secret || !apiKey) return new Response('Service not configured', { status: 503 });
  try {
    const body = await req.text();
    const wh = new Webhook(secret);
    const payload = wh.verify(body, Object.fromEntries(req.headers.entries())) as {
      user?: { phone?: string }; sms?: { otp?: string };
    };
    const phone = payload.user?.phone ?? '';
    const otp = payload.sms?.otp ?? '';
    if (!/^\+989\d{9}$/.test(phone) || !/^\d{4,8}$/.test(otp))
      return new Response('Invalid SMS request', { status: 400 });
    const recipient = '0' + phone.slice(3);
    const endpoint = `https://api.kavenegar.com/v1/${encodeURIComponent(apiKey)}/verify/lookup.json`;
    const params = new URLSearchParams({ receptor: recipient, token: otp, template: 'pelaklogin' });
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    let result: Response;
    try {
      result = await fetch(endpoint, {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(), signal: controller.signal,
      });
    } finally { clearTimeout(timer); }
    const json = await result.json().catch(() => null);
    if (!result.ok || json?.return?.status !== 200) {
      console.error('Kavenegar Lookup failure', result.status, json?.return?.status);
      return new Response('SMS delivery provider error', { status: 502 });
    }
    return new Response(JSON.stringify({}), { status: 200, headers: { 'Content-Type': 'application/json' } });
  } catch (error) {
    console.error('SMS hook verification or delivery error', String(error));
    return new Response('Unauthorized or delivery failed', { status: 401 });
  }
});
