// Supabase Edge Function: authenticated, bounded car-video frame analysis.
// Configure OPENAI_API_KEY as a Supabase secret. No video is uploaded or stored.
import { createClient } from 'npm:@supabase/supabase-js@2';
const allowedOrigin = 'https://sajadgolzar.github.io';
const cors = {'Access-Control-Allow-Origin': allowedOrigin,'Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
Deno.serve(async req => {
 if(req.method==='OPTIONS')return new Response('',{headers:cors});
 if(req.method!=='POST')return new Response('Method not allowed',{status:405,headers:cors});
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer\s+/i,'');if(!token)return new Response('Unauthorized',{status:401,headers:cors});
  const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!);
  const {data:{user},error}=await supabase.auth.getUser(token);if(error||!user)return new Response('Unauthorized',{status:401,headers:cors});
  const body=await req.json();const frames=body.frames,speech=body.speech;
  if(!Array.isArray(frames)||frames.length>3||frames.some((x:unknown)=>typeof x!=='string'||x.length>800000||!/^data:image\/jpeg;base64,/.test(x))||typeof speech!=='string'||speech.length>2500||(!frames.length&&!speech.trim()))return new Response('Invalid input',{status:400,headers:cors});
  const key=Deno.env.get('OPENAI_API_KEY');if(!key)return new Response('AI service not configured',{status:503,headers:cors});
  const prompt=`Extract ONLY supported details about a car from the user's Persian speech and video stills. Do not guess year, mileage, price, VIN, accidents, mechanical condition, or country. Uncertain fields must be null. Speech claims are user-provided, not verified. Return one JSON object with key fields and optional keys: title,make,model,trim,year,mileage,price,currency,country,city,description. currency only USD,AED,GEL,OMR,IRR; country only ایران,امارات,گرجستان,عمان. mileage integer km, price numeric. Keep description short Persian and attribute unverified claims to seller. User speech: ${speech}`;
  const input=[{type:'text',text:prompt},...frames.map((url:string)=>({type:'image_url',image_url:{url,detail:'low'}}))];
  const resp=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4o-mini',temperature:0,max_tokens:450,response_format:{type:'json_object'},messages:[{role:'user',content:input}]})});
  if(!resp.ok){console.error('AI provider status',resp.status);return new Response('AI provider unavailable',{status:502,headers:cors});}
  const result=await resp.json();const fields=JSON.parse(result.choices?.[0]?.message?.content||'{}');
  const valid=['title','make','model','trim','year','mileage','price','currency','country','city','description'];const clean:Record<string,string|number>={};for(const k of valid){const v=fields[k];if(typeof v==='string'&&v.length<=500||typeof v==='number'&&Number.isFinite(v))clean[k]=v;}
  return new Response(JSON.stringify({fields:clean}),{headers:{...cors,'Content-Type':'application/json'}});
 }catch(e){console.error('analyze-car error',String(e));return new Response('Processing error',{status:500,headers:cors});}
});
